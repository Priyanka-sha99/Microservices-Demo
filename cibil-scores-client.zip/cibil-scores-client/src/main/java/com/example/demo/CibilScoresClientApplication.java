package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.client.FindCibilScore;
import com.example.demo.entity.CibilScore;

@SpringBootApplication
public class CibilScoresClientApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext ctx= 	SpringApplication.run(CibilScoresClientApplication.class, args);
	FindCibilScore scoreFinder = ctx.getBean(FindCibilScore.class);
	
	CibilScore score = ctx.getBean(CibilScore.class);
	
	score.setPanId("ps1994");
	score.setCardHolderName("Manu");
	score.setPinCode(411038);
	System.out.println(scoreFinder.addScore(score));
	System.out.println(scoreFinder.getScores());
	ctx.close();
	}

}
