package com.example.demo.repo;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.CibilScore;

@Repository
public interface ScoreRepository extends PagingAndSortingRepository<CibilScore, String> {

}
