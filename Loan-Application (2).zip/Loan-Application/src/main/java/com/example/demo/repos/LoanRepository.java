package com.example.demo.repos;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.LoanApplication;

@Repository
public interface LoanRepository extends JpaRepository<LoanApplication, Double> {
	@Modifying
	@Transactional
	@Query(nativeQuery=true,value="update LoanApplication set status='approved' where PanCardNumber =:panId")
	public int  updateStatus(@Param("panId") String panId);

}
