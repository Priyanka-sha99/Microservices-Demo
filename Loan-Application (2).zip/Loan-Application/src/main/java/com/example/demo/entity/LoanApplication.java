package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class LoanApplication {

	@Id
	private int pId;
	private String PanCardNumber;
	private String customerName;
	private long PhoneNum;
	private String DateOfApplication;
	private double LoanAmount;
	
	private String status;
}
