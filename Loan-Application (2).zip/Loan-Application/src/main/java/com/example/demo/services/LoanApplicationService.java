package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.LoanApplication;
import com.example.demo.repos.LoanRepository;

import lombok.Setter;

@Service
@Setter
public class LoanApplicationService {

	@Autowired
	LoanRepository repo;
	
	
	public List<LoanApplication> findAll(){
		return this.repo.findAll();
	}
	
	public LoanApplication add(LoanApplication entity) {
		return this.repo.save(entity);
	}

	public void updateStatus(String panId) {
		this.repo.updateStatus(panId);
		
	}
}
