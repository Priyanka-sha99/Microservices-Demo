package com.example.demo.clients;



public interface CibilScoreClient {

}
