package com.example.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.LoanApplication;

@Repository
public interface LoanRepository extends JpaRepository<LoanApplication, Double> {
	
	@Query(nativeQuery=true,value="update LoanApplication set status='approved' where PanCardNumber=:panId")
	public LoanApplication updateStatus(String panId);

}
