package com.example.demo.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.clients.CibilScoreClient;
import com.example.demo.entity.CibilScore;
import com.example.demo.entity.LoanApplication;
import com.example.demo.services.LoanApplicationService;

import lombok.Setter;

@RestController
@Setter
@CrossOrigin(origins= "*")
public class LoanApplicationController {
	
	@Autowired
	LoanApplicationService service;
	
	@Autowired
	RestTemplate template;
	
	
	@GetMapping(path = "/api/v1/loan")
	public List<LoanApplication> getAll(){
		return this.service.findAll();
	}
	
	@PostMapping(produces= "application/json", consumes="application/json", path = "/api/v1/loan")
	public LoanApplication add(@RequestBody LoanApplication entity) {
		System.out.println("Hello");
		System.out.println(entity.getDateOfApplication());
		return this.service.add(entity);
	}
	
	@GetMapping(path="/api/v1/loan/process")
	public long process() {
		String message = "{message:processed}";
		System.out.println("inside123");
		List<LoanApplication> list = service.findAll();
		/*
		 * for(LoanApplication eachApplication: list) { String score =
		 * "http://localhost:4040/api/v1/cibilscore/"+eachApplication.getPanCardNumber()
		 * ; System.out.println("panCardNumber: " +score); }
		 */
		
		String url = "http://localhost:4040/api/v1/cibilscore/piu2020";
		long score=0;
		
			CibilScore response = template.getForObject(url, CibilScore.class);
			System.out.println("insid"+response);
			if(response.getCibilScore()>200)
			{
				service.updateStatus("piu2020");
			}
			System.out.println(response);
			
		
		
		return response.getCibilScore();
//		System.out.println("inside");
//		System.out.println(response);
//		//int score = response.getCibilScore();
//		if(response.getCibilScore()>500)
//			service.updateStatus(response.getPanId());
//		
//		System.out.println(response);
//		return response.getCibilScore();
	}
	
	
	@GetMapping(path="/api/v1/pendingloan")
	public List<LoanApplication> getAllPendingLoans(){
		List<LoanApplication> list = this.service.findAll();
		return list.stream().filter(eachLoan->eachLoan.getStatus().contains("pending")).collect(Collectors.toList());
	}
	
	@GetMapping(path="/api/v1/approvedloan")
	public List<LoanApplication> getAllApprovedLoans(){
		List<LoanApplication> list = this.service.findAll();
		return list.stream().filter(eachLoan->eachLoan.getStatus().contains("approved")).collect(Collectors.toList());
	}

}
