package com.example.demo.controllers;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.entity.CibilScore;
import com.example.demo.repos.CibilRepository;
import com.example.demo.services.CibilScoreService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.Setter;

@RestController
@Setter
@CrossOrigin(origins= "*")
public class CibilScoreController {

	@Autowired
	private CibilScoreService service;
	
	
	
	@GetMapping(path = "/api/v1/cibilscore")
	public List<CibilScore> getAll(){
		return this.service.findAll();
	}
	
	@PostMapping(produces= "application/json", consumes="application/json", path = "/api/v1/cibilscore")
	public CibilScore add(@RequestBody CibilScore entity) {
		return this.service.add(entity);
	}
	
	@PutMapping(path = "/api/v1/cibilscore")
	public CibilScore update(@RequestBody CibilScore entity) {
		return this.service.add(entity);
	}
	@Operation(description = "Delete a Given Entity if not found throws exception")
	@DeleteMapping(path = "/api/v1/cibilscore")
	public CibilScore delete(@RequestBody CibilScore entity, HttpServletResponse response) {
		
		
		CibilScore deletedEntity = this.service.remove(entity);;
		try {
	
		if(deletedEntity == null) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Entity you want to delete not Found");
		}
		}catch (ResponseStatusException e) {
			throw e;
		}
		return deletedEntity;
	}
	
}
