package com.example.demo.controller;

import java.util.Optional;

import javax.xml.ws.FaultAction;

import org.apache.commons.logging.Log;
import org.bouncycastle.crypto.RuntimeCryptoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Image;
import com.example.demo.repo.ImageRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;


@RestController
@CrossOrigin(origins="*")
@Slf4j
public class ImageController {

	@Autowired
	private ImageRepository repo;
	
	@Autowired
	private Image defaultImage;
	
	
	@GetMapping(path="/api/v1/images/{id}")
	@HystrixCommand(fallbackMethod="fallBackMethodForFindById")
	public Image findById(@PathVariable("id") long id) {
		
		Image image = null;
		
		Optional<Image> response = this.repo.findById(id);
		
		if(response.isPresent()) {
			image = response.get();
			log.info("Imgae found");
		}else {
			log.info("Image not found");
			throw new RuntimeException();
		}
		
		return image;
	}
	
	public Image fallBackMethodForFindById(long id) {
		log.info("fallback method executed");
		return this.defaultImage;
	}
}

